// Resolution settings for E2B desktop sandbox (4:3 aspect ratio)
export const resolution = { x: 1024, y: 768 };
